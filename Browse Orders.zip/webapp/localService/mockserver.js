// sap.ui.define(["sap/ui/core/util/MockServer","sap/ui/model/json/JSONModel","sap/base/Log"],function(e,t,r){"use strict";var a,o="sap/ui/demo/orderbrowser/",i=o+"localService/mockdata";var n={init:function(n){var s=n||{};return new Promise(function(n){var u=sap.ui.require.toUrl(o+"manifest.json"),c=new t(u);c.attachRequestCompleted(function(){var t=new URLSearchParams(window.location.search),u=sap.ui.require.toUrl(i),p=c.getProperty("/sap.app/dataSources/mainService"),d=sap.ui.require.toUrl(o+p.settings.localUri),f=/.*\/$/.test(p.uri)?p.uri:p.uri+"/";if(!a){a=new e({rootUri:f})}else{a.stop()}e.config({autoRespond:true,autoRespondAfter:s.delay||t.get("serverDelay")||500});a.simulate(d,{sMockdataBaseUrl:u,bGenerateMissingMockData:true});var l=a.getRequests();var m=function(e,t,r){r.response=function(r){r.respond(e,{"Content-Type":"text/plain;charset=utf-8"},t)}};if(s.metadataError||t.get("metadataError")){l.forEach(function(e){if(e.path.toString().indexOf("$metadata")>-1){m(500,"metadata Error",e)}})}var v=s.errorType||t.get("errorType"),g=v==="badRequest"?400:500;if(v){l.forEach(function(e){m(g,v,e)})}a.setRequests(l);a.start();r.info("Running the app with mock data");n()});c.attachRequestFailed(function(){r.error("Failed to load application manifest");n()})})},getMockServer:function(){return a}};return n});
// //# sourceMappingURL=mockserver.js.map


sap.ui.define([
    "sap/ui/core/util/MockServer",
    "sap/ui/model/json/JSONModel", 
    "sap/base/Log"
], function(e, t, r) {
    "use strict";

    var a;
    var o = "sap/ui/demo/orderbrowser/";
    var i = o + "data";

    var n = {
        init: function(n) {
            var s = n || {};

            return new Promise(function(n) {
                var u = sap.ui.require.toUrl(o + "manifest.json");
                var c = new t(u);

                c.attachRequestCompleted(function() {
                    var t = new URLSearchParams(window.location.search);
                    var u = sap.ui.require.toUrl(i);
                    var p = c.getProperty("/sap.app/dataSources/mainService");
                    var d = sap.ui.require.toUrl(o + p.settings.localUri);
                    var f = /.*\/$/.test(p.uri) ? p.uri : p.uri + "/";

                    if (!a) {
                        a = new e({
                            rootUri: f
                        });
                    } else {
                        a.stop();
                    }

                    e.config({
                        autoRespond: true,
                        autoRespondAfter: s.delay || t.get("serverDelay") || 500
                    });

                    a.simulate(d, {
                        sMockdataBaseUrl: u,
                        bGenerateMissingMockData: true
                    });

                    var l = a.getRequests();
                    var m = function(e, t, r) {
                        r.response = function(r) {
                            r.respond(e, {
                                "Content-Type": "text/plain;charset=utf-8"
                            }, t);
                        };
                    };

                    if (s.metadataError || t.get("metadataError")) {
                        l.forEach(function(e) {
                            if (e.path.toString().indexOf("$metadata") > -1) {
                                m(500, "metadata Error", e);
                            }
                        });
                    }

                    var v = s.errorType || t.get("errorType");
                    var g = v === "badRequest" ? 400 : 500;

                    if (v) {
                        l.forEach(function(e) {
                            m(g, v, e);
                        });
                    }

                    a.setRequests(l);
                    a.start();

                    r.info("Running the app with mock data");
                    n();
                });

                c.attachRequestFailed(function() {
                    r.error("Failed to load application manifest");
                    n();
                });
            });
        },

        getMockServer: function() {
            return a;
        }
    };

    return n;
});