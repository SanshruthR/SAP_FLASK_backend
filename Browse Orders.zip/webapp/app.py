import os
import json
from flask import Flask, render_template, jsonify, request, redirect, url_for, session, flash
from functools import wraps

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Used for session management

DATA_FOLDER = os.path.join(os.path.dirname(__file__), 'data')
ADMIN_USERNAME = os.environ.get('username')
ADMIN_PASSWORD = os.environ.get('password')

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash('Please log in to access this page', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session or not session.get('is_admin'):
            flash('You do not have permission to access this page', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
@login_required
def index():
    return render_template('index.html', is_admin=session.get('is_admin', False))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:  # Plain text comparison
            session['logged_in'] = True
            session['is_admin'] = True
            session['username'] = username
            flash('Login successful', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid credentials', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out', 'success')
    return redirect(url_for('login'))

@app.route('/data')
@login_required
def get_json_files():
    try:
        files = [f for f in os.listdir(DATA_FOLDER) if f.endswith('.json')]
        return jsonify(files)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/data/<filename>')
@login_required
def get_json_content(filename):
    try:
        filepath = os.path.join(DATA_FOLDER, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/data/<filename>', methods=['PUT'])
@admin_required
def save_json_content(filename):
    try:
        filepath = os.path.join(DATA_FOLDER, filename)
        data = request.get_json()
        
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=4)
        
        return jsonify({"message": "File saved successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # Ensure data directory exists
    os.makedirs(DATA_FOLDER, exist_ok=True)
    app.run(debug=True)
