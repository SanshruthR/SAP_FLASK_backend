/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["sap/base/i18n/ResourceBundle","jquery.sap.global"],function(e,jQuery){"use strict";jQuery.sap.resources=function(){return e.create.apply(e,arguments)};jQuery.sap.resources.isBundle=function(s){return s instanceof e};jQuery.sap.resources._getFallbackLocales=e._getFallbackLocales;return jQuery});
//# sourceMappingURL=jquery.sap.resources.js.map