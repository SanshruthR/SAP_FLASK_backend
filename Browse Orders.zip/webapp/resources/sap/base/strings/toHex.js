/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define([],function(){"use strict";var t=function(t,r){var n=t.toString(16);if(r){n=n.padStart(r,"0")}return n};return t});
//# sourceMappingURL=toHex.js.map