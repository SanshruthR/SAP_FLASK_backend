/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define([],function(){"use strict";var e=function(e){var n=e.length,r=0;while(n--){r=(r<<5)-r+e.charCodeAt(n);r=r&r}return r};return e});
//# sourceMappingURL=hash.js.map