/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define([],function(){"use strict";var r=function(r){var e=" ",t=" ";if(typeof r!=="string"){return r}return r.replaceAll("\t",e+e).replaceAll(e+e,e+t)};return r});
//# sourceMappingURL=whitespaceReplacer.js.map