/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["./fetch","sap/ui/base/SyncPromise"],function(e,n){"use strict";function t(t,i,r){var s;if(r===true){s={promiseImpl:n}}return e(t,i,s)}t.ContentTypes=e.ContentTypes;return t});
//# sourceMappingURL=mixedFetch.js.map