/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define([],function(){"use strict";var e=function(e,t,n,r){var i=n[r];var u={configurable:true,get:function(){return i},set:function(e){i=e}};Object.defineProperty(e,t,u);Object.defineProperty(n,r,u)};return e});
//# sourceMappingURL=defineCoupledProperty.js.map