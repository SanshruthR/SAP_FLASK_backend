/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["./_merge"],function(r){"use strict";var u=function(){var u=[true,true];u.push.apply(u,arguments);return r.apply(null,u)};return u});
//# sourceMappingURL=deepExtend.js.map