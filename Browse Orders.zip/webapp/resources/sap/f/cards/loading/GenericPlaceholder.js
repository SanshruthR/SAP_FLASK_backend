/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["sap/f/cards/loading/PlaceholderBase","./GenericPlaceholderRenderer"],function(e,r){"use strict";var a=e.extend("sap.f.cards.loading.GenericPlaceholder",{metadata:{library:"sap.f"},renderer:r});return a});
//# sourceMappingURL=GenericPlaceholder.js.map