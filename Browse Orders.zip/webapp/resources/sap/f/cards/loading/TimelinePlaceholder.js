/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["sap/f/cards/loading/PlaceholderBase","./TimelinePlaceholderRenderer"],function(e,i){"use strict";var r=e.extend("sap.f.cards.loading.TimelinePlaceholder",{metadata:{library:"sap.f",properties:{minItems:{type:"int",group:"Misc"},item:{type:"any"},itemHeight:{type:"sap.ui.core.CSSSize"}}},renderer:i});return r});
//# sourceMappingURL=TimelinePlaceholder.js.map