/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["sap/f/cards/loading/PlaceholderBase","./AnalyticalPlaceholderRenderer"],function(e,a){"use strict";var r=e.extend("sap.f.cards.loading.AnalyticalPlaceholder",{metadata:{library:"sap.f",properties:{chartType:{type:"string",defaultValue:""},minHeight:{type:"string",defaultValue:""}}},renderer:a});return r});
//# sourceMappingURL=AnalyticalPlaceholder.js.map