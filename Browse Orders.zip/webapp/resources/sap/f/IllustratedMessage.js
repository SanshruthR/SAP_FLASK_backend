/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["sap/m/IllustratedMessage","sap/m/IllustratedMessageRenderer","./library"],function(e,r){"use strict";var a=e.extend("sap.f.IllustratedMessage",{metadata:{library:"sap.f",deprecated:true,properties:{}},renderer:r});return a});
//# sourceMappingURL=IllustratedMessage.js.map