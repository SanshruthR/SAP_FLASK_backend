/*!
 * OpenUI5
 * (c) Copyright 2009-2024 SAP SE or an SAP affiliate company.
 * Licensed under the Apache License, Version 2.0 - see LICENSE.txt.
 */
sap.ui.define(["sap/ui/core/Element","./library"],function(l,e){"use strict";var a=l.extend("sap.f.FlexibleColumnLayoutAccessibleLandmarkInfo",{metadata:{library:"sap.f",properties:{firstColumnLabel:{type:"string",defaultValue:null},middleColumnLabel:{type:"string",defaultValue:null},lastColumnLabel:{type:"string",defaultValue:null},firstColumnBackArrowLabel:{type:"string",defaultValue:null},middleColumnForwardArrowLabel:{type:"string",defaultValue:null},middleColumnBackArrowLabel:{type:"string",defaultValue:null},lastColumnForwardArrowLabel:{type:"string",defaultValue:null}}}});return a});
//# sourceMappingURL=FlexibleColumnLayoutAccessibleLandmarkInfo.js.map